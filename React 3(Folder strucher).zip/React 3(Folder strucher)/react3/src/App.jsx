import React from 'react'
import './index.css'
const App = () => {
  return (
    <div id='he'>
      hello
    </div>
  )
}

export default App
